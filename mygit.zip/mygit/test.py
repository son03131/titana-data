import pandas as pd
from bs4 import BeautifulSoup
from requests import get
import time
import random

# Đọc danh sách công ty từ file CSV
df = pd.read_csv("c:/mygit/enterprise_df_3501_4000_v2.csv")
corp_name_list = df['기업명'].dropna().unique().tolist()  # bỏ các ô trống nếu có

def get_jobkorea_data(corp_name_list, page_no=1):
    jobkorea_data = []
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
    
    for corp_name in corp_name_list:
        try:
            url = f"https://www.jobkorea.co.kr/Search/?stext={corp_name}&tabType=corp&Page_No={page_no}"
            response = get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, "html.parser")

            flex_containers = soup.find_all(
                "div",
                class_="Flex_display_flex__i0l0hl2 Flex_direction_row__i0l0hl3 Flex_justify_space-between__i0l0hlf",
            )
            print(f"기업: {corp_name} - {len(flex_containers)}개 발견")

            for container in flex_containers:
                inner_flex = container.find(
                    "div",
                    class_="Flex_display_flex__i0l0hl2 Flex_gap_space12__i0l0hls Flex_direction_row__i0l0hl3",
                )
                if not inner_flex:
                    continue

                spans = inner_flex.find_all("span", class_="Typography_variant_size14__344nw27")

                if len(spans) >= 3:
                    if len(spans) == 3:
                        corp_type, corp_location, corp_industry = [s.get_text(strip=True) for s in spans]
                    else:  # nếu có 4 span
                        corp_type, corp_location, corp_industry = [spans[1].get_text(strip=True), spans[2].get_text(strip=True), spans[3].get_text(strip=True)]
                else:
                    print(f"{corp_name}: 정보 부족")
                    continue

                parent = container.find_parent('div', class_="Flex_display_flex__i0l0hl2 Flex_gap_space4__i0l0hly Flex_direction_column__i0l0hl4")
                if not parent:
                    print(f"{corp_name}: 부모 div 못찾음")
                    continue

                a_tag = parent.find('a', href=True)
                if not a_tag:
                    print(f"{corp_name}: 링크 없음")
                    continue

                # Truy cập trang chi tiết công ty
                try:
                    detail_response = get(a_tag['href'], headers=headers, timeout=10)
                    detail_soup = BeautifulSoup(detail_response.text, "html.parser")
                except Exception as e:
                    print(f"{corp_name}: 상세 페이지 요청 실패 - {e}")
                    continue

                # 방어코드: 값이 없을 경우 빈 문자열 처리
                def safe_extract(selector):
                    tag = detail_soup.select_one(selector)
                    return tag.text.strip() if tag else ""

                capital = safe_extract("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(3) > td:nth-child(2) > div > div > div.value")
                sales = safe_extract("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(3) > td:nth-child(4) > div > div > div.value")
                ceo = safe_extract("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(4) > td:nth-child(2) > div > div > div.value")
                foundation_date = safe_extract("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(2) > td:nth-child(4) > div > div > div.value")

                jobkorea_data.append({
                    "기업명": corp_name,
                    "기업형태": corp_type,
                    "지역": corp_location,
                    "업종": corp_industry,
                    "자본금": capital,
                    "매출액": sales,
                    "대표자": ceo,
                    "설립일": foundation_date
                })

            # Mỗi công ty nghỉ random từ 2~5 giây để tránh bị chặn IP
            time.sleep(random.uniform(2, 5))

        except Exception as e:
            print(f"{corp_name}: 전체 에러 발생 - {e}")
            continue

    return pd.DataFrame(jobkorea_data)


if __name__ == "__main__":
    result_df = get_jobkorea_data(corp_name_list)
    result_df.to_csv("jobkorea_data_final.csv", index=False, encoding="utf-8-sig")
    print(result_df.head())
