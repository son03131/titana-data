import pandas as pd  # 데이터 처리 및 CSV 파일 저장을 위한 라이브러리
from bs4 import BeautifulSoup  # HTML 파싱을 위한 라이브러리
from requests import get  # HTTP 요청을 보내기 위한 라이브러리 url -> 데이터를 가져오려고 사용하는 라이브러리 
import time

df = pd.read_csv("first_5.csv")


def get_jobkorea_data(corp_name_list, page_no=1):
    """
    JobKorea 웹사이트에서 기업 정보를 크롤링하여 데이터프레임으로 반환하는 함수.
    Args:
        corp_name_list (List[str]): 검색할 기업명 리스트.
        page_no (int): 검색 결과 페이지 번호 (기본값: 1).
    Returns:
        pd.DataFrame: 크롤링된 기업 정보를 포함하는 데이터프레임.
    """
    jobkorea_data = []  # 크롤링된 데이터를 저장할 리스트
    headers = {
        # HTTP 요청에 사용할 User-Agent 헤더 설정 (브라우저처럼 보이게 함)
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
    for corp_name in corp_name_list: # 삼성전자
        # 검색 URL 생성 (기업명과 페이지 번호를 포함)
        #       https://www.jobkorea.co.kr/Search?stext=%EC%82%BC%EC%84%B1%EC%A0%84%EC%9E%90&Page_No=4&tabType=corp
        url = f"https://www.jobkorea.co.kr/Search/?stext={corp_name}&tabType=corp&Page_No={page_no}"
        response = get(url, headers=headers)  # HTTP GET 요청을 보내고 응답 받기
        soup = BeautifulSoup(response.text, "html.parser")  # HTML 응답을 파싱

        # Flex 컴포넌트 구조에서 기업 정보를 포함하는 부분 찾기
        #           Flex_display_flex__i0l0hl2 Flex_direction_row__i0l0hl3 Flex_justify_space-between__i0l0hlf
        #           .Flex_display_flex__i0l0hl2 .Flex_direction_row__i0l0hl3 Flex_justify_space-between__i0l0hlf
        flex_containers = soup.find_all(
            "div",
            class_="Flex_display_flex__i0l0hl2 Flex_direction_row__i0l0hl3 Flex_justify_space-between__i0l0hlf",
        )

        # Flex 컨테이너 개수를 출력 (디버깅용)
        print(f"Found {len(flex_containers)} flex containers for {corp_name}")
        
        for container in flex_containers: # 10개 중에 1개씩 처리 한다.
            # 내부 Flex 컨테이너 찾기
            #           Flex_display_flex__i0l0hl2 Flex_gap_space12__i0l0hls Flex_direction_row__i0l0hl3
            inner_flex = container.find(
                "div",
                class_="Flex_display_flex__i0l0hl2 Flex_gap_space12__i0l0hls Flex_direction_row__i0l0hl3",
            )
            if not inner_flex:  # 내부 Flex 컨테이너가 없으면 건너뜀
                continue

            # span 태그에서 정보 추출
            spans = inner_flex.find_all(
                "span", class_="Typography_variant_size14__344nw27"
            )
            #print(spans)
            
            if len(spans) >= 3:  # 필요한 정보가 포함된 span 태그가 3개 이상인 경우
                if len(spans) == 3:
                    corp_type = (
                        spans[0].get_text(strip=True) if spans[0] else None
                    )  # 기업형태
                    corp_location = (
                        spans[1].get_text(strip=True) if spans[1] else None
                    )  # 지역
                    corp_industry = (
                        spans[2].get_text(strip=True) if spans[2] else None
                    )  # 업종
                elif len(spans) == 4: 
                    corp_type = (
                        spans[1].get_text(strip=True) if spans[1] else None
                    )  # 기업형태
                    corp_location = (
                        spans[2].get_text(strip=True) if spans[2] else None
                    )  # 지역
                    corp_industry = (
                        spans[3].get_text(strip=True) if spans[3] else None
                    )  # 업종
                
                # 찾은 회사의 링크 URL을 구한다. 
                # get()을 이용해서 (requests.get) 이동한다.
                # 이동한 상세 페이지에서 자본금과 매출액을 구해온다.
                # 추출된 데이터를 딕셔너리로 저장
                
                if container:
                    #                                             Flex_display_flex__i0l0hl2 Flex_gap_space4__i0l0hly Flex_direction_column__i0l0hl4
                    parent = container.find_parent('div', class_="Flex_display_flex__i0l0hl2 Flex_gap_space4__i0l0hly Flex_direction_column__i0l0hl4")
                    if parent:
                        a_tag = parent.find('a', href=True)
                        #print(a_tag)
                        if a_tag:
                            print("링크:", a_tag['href'])
                            # 방어코드를 넣으세요.  select_one으로 가져온 결과가 None 일때의 처리 등.
                            detail_response = get(a_tag['href'], headers=headers)  # HTTP GET 요청을 보내고 응답 받기
                            detail_soup = BeautifulSoup(detail_response.text, "html.parser")  # HTML 응답을 파싱
                            # #company-body > div.company-body-infomation.is-fixed > div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(3) > td:nth-child(2) > div > div > div.value
                            # value_container가 None 일 때 오류가 발생하지 않도록 처리해주세요(방어코드)
                            value_container = detail_soup.select_one("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(3) > td:nth-child(2) > div > div > div.value")
                            if not value_container:
                                capital_tag = None
                            else:
                                capital_tag = value_container.select_one(".value")
                            if capital_tag:
                                capital = capital_tag.text 
                            else:
                                capital = ""
                            print("자본금: ", capital)
                            # #company-body > div.company-body-infomation.is-fixed > div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(3) > td:nth-child(4) > div > div > div.value
                            sales_container = detail_soup.select_one("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(3) > td:nth-child(4) > div > div > div.value")
                            if sales_container:
                                sales_tag = sales_container.select_one(".value")
                            else:
                                sales_tag = None
                            if sales_tag:
                                sales = sales_tag.text 
                            else:
                                sales = ""
                            print("매출액: ", sales)
                            ceo_tag = detail_soup.select_one("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(4) > td:nth-child(2) > div > div > div.value")
                            if ceo_tag:
                                ceo = ceo_tag.text 
                            else:
                                ceo = ""
                            print("대표자: ", ceo)
                            # 설립일: #company-body > div.company-body-infomation.is-fixed > div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(2) > td:nth-child(4) > div > div > div.value
                            foundation_date_tag = detail_soup.select_one("div.company-infomation-row.basic-infomation > div > table > tbody > tr:nth-child(2) > td:nth-child(4) > div > div > div.value")
                            if foundation_date_tag:
                                foundation_date = foundation_date_tag.text 
                            else:
                                foundation_date = ""
                            print("설립일", foundation_date)
                            
                        else:
                            pass
                            #print("a 태그를 찾을 수 없습니다.")
                    else:
                        print("부모 div를 찾을 수 없습니다.")
                else:
                    print("대상 div를 찾을 수 없습니다.")
                    
                jobkorea_data.append(
                    {
                        "기업명": corp_name,
                        "기업형태": corp_type,
                        "지역": corp_location,
                        "업종": corp_industry,
                        "자본금": capital,
                        "매출액": sales,
                        "대표자": ceo,
                        "설립일": foundation_date
                    }
                )
                # 추출된 데이터를 출력 (디버깅용)
                print(f"추출된 데이터: {corp_name}, {corp_type}, {corp_location}, {corp_industry}")
            else:
                # span 태그가 부족한 경우 경고 메시지 출력
                print(f"정보가 충분하지 않음: {len(spans)} 개의 span 태그 발견")
            time.sleep(15)
    # 크롤링된 데이터를 데이터프레임으로 변환하여 반환

    return pd.DataFrame(jobkorea_data)


if __name__ == "__main__": # 직접 호출 시에 실행됨 $python jobKorea_sales.py 
    """
    메인 실행 코드: 테스트용으로 기업명을 '벡스인텔리전스'로 설정하여 크롤링 수행.
    """
    # 테스트용 기업명 리스트
    
    df = pd.read_csv("first_5.csv")

    corp_name_list = df['기업명'].dropna().unique().tolist()

    # test_data = get_jobkorea_data(corp_name_list[])


    # 실제 사용 시: CSV 파일에서 기업명 리스트를 불러올 수 있음 
    # 인덱스 
    #corp_name_list = pd.read_csv("enterprise_df_sklee_utf8_data.csv")["기업명"].unique().tolist()
    print(corp_name_list)
    # 최초의 소스코드에서는 기업명으로 검색하고 검색창이 있는 목록에서 기업형태, 지역, 업종 
    # 기업상세정보에서 설립일, 대표자 추가 할 것 
    test_data = get_jobkorea_data(corp_name_list)

    # 결과를 CSV 파일로 저장 jobkorea_data_자기번호.csv
    # 이메일로 조교님에게 소스코드와 결과파일  jobkorea_data_12.csv
    test_data.to_csv("jobkorea_data_12.csv", index=False, encoding="utf-8-sig")




    # 결과 출력
    print(test_data.head())
